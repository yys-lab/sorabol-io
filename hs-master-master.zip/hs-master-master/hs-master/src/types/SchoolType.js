module.exports = {
	1: "KINDERGARTEN",
	2: "ELEMENTARY",
	3: "MIDDLE",
	4: "HIGH",

	"KINDERGARTEN": 1,
	"ELEMENTARY": 2,
	"MIDDLE": 3,
	"HIGH": 4
};